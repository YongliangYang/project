﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Handiness2.Schema.Exporter
{
    public static class CommandAssistor
    {
        /// <summary>
        /// 获取指定名称的参数的值
        /// </summary>
        /// <param name="name">参数名称</param>
        /// <returns>对应的字符串值</returns>
        public static String GetArgsValue(String name)
        {
            String value = null;
            return value;
        }
    }
}
