﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Handiness2.Parser
{
    public class LambdaParser
    {
    }
}
