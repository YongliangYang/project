﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Handiness2.Schema
{
    /// <summary>
    /// 映射目标对象的表结构信息
    /// </summary>
    [Serializable]
    public class TableSchema : SchemaBase
    {
    }
}
