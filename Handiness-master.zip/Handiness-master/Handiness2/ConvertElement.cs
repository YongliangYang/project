﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Handiness2
{
    /// <summary>
    /// 基础的转换元素，包含可转换至 SQL 语句与参数的信息
    /// </summary>
    public class ConvertElement
    {

    }
}
