﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Handiness2.Schema.Exporter.Windows
{
    public enum SchemaDifferenceType
    {
        None = 0,
        Add = 1,
        Modify = 2,
        Delete = 3
    }
}
