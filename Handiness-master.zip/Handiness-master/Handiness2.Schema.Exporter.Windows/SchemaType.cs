﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Handiness2.Schema.Exporter.Windows
{

    public enum SchemaType
    {
        Table = 1,
        View = 2,
        Procedure = 3,
        Function = 4

    }
}
