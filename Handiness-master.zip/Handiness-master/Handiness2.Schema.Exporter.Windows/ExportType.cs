﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Handiness2.Schema.Exporter.Windows
{
    public enum ExportType
    {
        Excel=0
    }
}
