﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgilityConfig;
namespace Handiness2.Schema.Exporter.Windows
{
  
    public class ExportConfig 
    {
        
    }
}
